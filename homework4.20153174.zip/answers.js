function answer_1() {
  document.getElementById("q1-answer").innerHTML = "<ul><li>D - Document</li><li>O - Object</li><li>M - Model</li></ul>";
}
function answer_2() {
  document.getElementById("q2-answer").innerHTML = "<ol><li>Javascript can approach most of elements in document dynamically through DOM. <br>So, javascript can control features, contents, and attributes of documents.</li><li>Moreover, javascript make new elements or contents and apply to document whenever users need it. <br>Thus, DOM approach is one of the most necessary works for rich interaction on webpage.</li></ol>";
}
function answer_3() {
var tags = document.getElementsByClassName ( "q34-answer" );
tags[ 0 ].innerHTML="<ul><li>parent node - The parentNode returns the parent node of the specified node, as a Node object. A node directly above a node.</li><li>child node - The childNodes returns a collection of a node's child nodes, as a NodeList object. Nodes one level directly below.</li><li>sibling node - Nodes at the same level(or same parent node.) And there are nextsibiling and previous sibling nodes</li><li>descendant node - The (parent descendant) selector selects all elements that are descendants of a specified element. <br>A descendant of an element could be a child, grandchild, great-grandchild, etc, of that element. <br>A set of nodes any number of levels below another node.</li><li>ancestor node - The (child ancestor) selector selects all elements that are ancestors of a specified element.<br>A ancestor of an element could be a parent, grandparent, great-grandparent, etc, of that element.<br>A set of nodes above a node in a tree.</li></ul>";
}
function answer_4() {
var tags = document.getElementsByClassName ( "q34-answer" );
tags[ 1 ].innerHTML="<ul><li>document.getElementById() - The getElementById() method returns the element that has the ID attribute with the specified value.<br>This method is one of the most common methods in the HTML DOM, and is used almost every time you want to manipulate, or get information from, an element on your document.<br>Returns null if no elements with the specified ID exists. <br>An ID should be unique within a page(can return one element).</li><li>document.getElementsByClassName() - The getElementsByClassName() method returns a collection of all elements in the document with the specified class name, as a NodeList object.<br> we can use the length property of the NodeList object to determine the number of elements with a specified class name, then we can loop through all elements and extract the info we want(can return many elements).</li><li>document.getElementsByName - The getElementsByName() method returns a collection of all elements in the document with the specified name <br>we can use the length property of the NodeList object to determine the number of elements with the specified name, then we can loop through all elements and extract the info we want(can return many elements).</li><li>document.getElementsByTagName() - The getElementsByTagName() method returns a collection of all elements in the document with the specified tag name.<br>we can use the length property of the NodeList object to determine the number of elements with the specified name, then we can loop through all elements and extract the info we want(can return many elements).</li></ul>";
}
var a_51 = $('a')[0];
var a_52 = $('a')[1]
$(a_51).click(function () {
    $(a_51).text("Answer5");
})
$(a_52).click(function () {
    $(a_52).text("Answer5");
})
var a_61 = $('.item')[0];
var a_62 = $('.item')[1];
$(a_61).click(function () {
    $(a_61).attr('style', 'font-size:3em;');
})
$(a_62).click(function () {
    $(a_62).attr('style', 'font-size:3em;');
})
var a_71 = $('.demo')[0];
var a_72 = $('.demo')[2];
$(a_71).dblclick(function () {
    $(a_71).attr('style', 'color:blue');
})
$(a_72).dblclick(function () {
    $(a_72).attr('style', 'color:blue');
})
